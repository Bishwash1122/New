# Pubg-freeze

Hello! there, i am Faizan Quazi an Indian Ethical Hacker, I've found a bug in pubg in-game server

,Here is the detailed explanation how to exploit these bug

If you face any difficulty in, initiating these attack just email me

On faizii.official@gmail.com or join my telegram channel 



https://t.me/joinchat/O3iC0xrTzopNaQ_C3OsixQ



These attack is only for educational purposes i am not at all 

Responsible for any illegal rights happened with you.

Thank you! 

Regards faizii 😊

How to use 

Step 1.Just execute setup.sh with root permission.
Step 2.open termux and type "tsu" without quote.
Step 3.paste the ip address of server.
Step 4.paste the port of server.
Done attack started 
To stop these attack press ctrl+c

How to get the ip address
Use any MIM vpn to check any new udp trans-listeners
Recommended vpn (netguard, http cannery ,netcapture )

In every match makeing the trans-listeners attached in
Your client is identified by ports
Port 2000-2003 (client alive status updater)
Port (10000-11500 in-game activity Updater)
We need to attacks on in-game activity updater
Copy the ip + port and  past on termux 
Done !👍 Enjoy 😊 


 
